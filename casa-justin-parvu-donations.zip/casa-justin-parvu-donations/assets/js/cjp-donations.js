(function () {
  function formatNumber(value, decimals) {
    return new Intl.NumberFormat('ro-RO', {
      minimumFractionDigits: decimals,
      maximumFractionDigits: decimals
    }).format(Number(value || 0));
  }

  function setProgressBar(el, percent) {
    if (!el) return;
    const safePercent = Math.max(0, Math.min(100, Number(percent || 0)));
    el.style.width = safePercent + '%';
  }

  function renderRecent(listEl, recent) {
    if (!listEl) return;
    if (!Array.isArray(recent) || recent.length === 0) {
      listEl.innerHTML = '<p class="cjp-empty">Încă nu există donații înregistrate.</p>';
      return;
    }

    const html = recent.map(function (item) {
      const donor = (item.donor_name || 'Donator anonim').toString();
      const type = (item.donation_type || 'general_donation').toString();
      const amount = formatNumber(item.amount || 0, 2);
      const currency = (item.currency || 'RON').toString();
      const rawDate = (item.created_at || '').toString().replace(' ', 'T');
      const date = rawDate ? new Date(rawDate) : new Date();
      const dateLabel = isNaN(date.getTime()) ? '' : date.toLocaleString('ro-RO');

      return '<div class="cjp-recent-item">'
        + '<div><strong>' + donor + '</strong><span>' + type + '</span></div>'
        + '<div><strong>' + amount + ' ' + currency + '</strong><span>' + dateLabel + '</span></div>'
        + '</div>';
    }).join('');

    listEl.innerHTML = html;
  }

  function updateFromStats(stats) {
    if (!stats || typeof stats !== 'object') return;

    const totals = stats.totals || {};
    const materials = stats.materials || {};

    const eurText = document.getElementById('cjp-eur-progress-text');
    const eurBar = document.getElementById('cjp-eur-progress-bar');
    if (eurText) {
      eurText.textContent = formatNumber(totals.eur_raised || 0, 2)
        + ' / '
        + formatNumber(totals.eur_goal || 0, 0)
        + ' EUR';
    }
    setProgressBar(eurBar, totals.percent || 0);

    Object.keys(materials).forEach(function (key) {
      const item = materials[key] || {};
      const card = document.querySelector('.cjp-material-card[data-key="' + key + '"]');
      if (!card) return;

      const current = card.querySelector('.cjp-current');
      const target = card.querySelector('.cjp-target');
      const unit = card.querySelector('.cjp-unit');
      const bar = card.querySelector('.cjp-material-progress');

      if (current) current.textContent = formatNumber(item.current || 0, 2);
      if (target) target.textContent = formatNumber(item.target || 0, 2);
      if (unit) unit.textContent = (item.unit || '').toString();
      setProgressBar(bar, item.percent || 0);
    });

    const list = document.getElementById('cjp-recent-list');
    renderRecent(list, stats.recent_donations || []);
  }

  async function fetchStats() {
    if (!window.cjpDonationsData || !window.cjpDonationsData.statsEndpoint) {
      return;
    }

    try {
      const res = await fetch(window.cjpDonationsData.statsEndpoint, { credentials: 'same-origin' });
      if (!res.ok) return;
      const stats = await res.json();
      updateFromStats(stats);
    } catch (error) {
      console.error('CJP donations polling failed:', error);
    }
  }

  document.addEventListener('DOMContentLoaded', function () {
    fetchStats();
    const poll = Number(window.cjpDonationsData && window.cjpDonationsData.pollInterval) || 30000;
    window.setInterval(fetchStats, poll);
  });
})();
