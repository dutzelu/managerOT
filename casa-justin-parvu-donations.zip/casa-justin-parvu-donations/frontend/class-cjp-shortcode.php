<?php

if (!defined('ABSPATH')) {
    exit;
}

class CJP_Shortcode
{
    private static bool $should_enqueue_assets = false;

    public static function init(): void
    {
        add_shortcode('donations_page', [self::class, 'render_shortcode']);
        add_action('wp_enqueue_scripts', [self::class, 'register_assets']);
    }

    public static function register_assets(): void
    {
        if (!self::$should_enqueue_assets) {
            return;
        }

        wp_enqueue_style(
            'cjp-donations',
            CJP_DONATIONS_URL . 'assets/css/cjp-donations.css',
            [],
            CJP_DONATIONS_VERSION
        );

        wp_enqueue_script(
            'cjp-donations',
            CJP_DONATIONS_URL . 'assets/js/cjp-donations.js',
            [],
            CJP_DONATIONS_VERSION,
            true
        );

        wp_localize_script('cjp-donations', 'cjpDonationsData', [
            'statsEndpoint' => esc_url_raw(rest_url('cjp/v1/stats')),
            'pollInterval' => 30000,
        ]);
    }

    public static function render_shortcode(): string
    {
        self::$should_enqueue_assets = true;

        $stats = CJP_Stats::get_stats();
        $links = CJP_Stats::get_payment_links();

        $one_time_cards = $links['one_time'] ?? [];
        $monthly_cards = $links['monthly'] ?? [];

        $totals = $stats['totals'] ?? [];
        $materials = $stats['materials'] ?? [];
        $recent = $stats['recent_donations'] ?? [];

        ob_start();
        ?>
        <div class="cjp-donations-page" id="cjp-donations-page">
            <section class="cjp-section cjp-hero">
                <h1>Construim Casa Justin Pârvu</h1>
                <p class="cjp-subtitle">Ajută la construirea centrului pentru educația tinerilor.</p>

                <div class="cjp-goals-grid">
                    <div class="cjp-goal-item">
                        <span>Fundație</span>
                        <strong><?php echo esc_html(number_format_i18n((float) ($totals['foundation_target'] ?? 20000), 0)); ?> EUR</strong>
                    </div>
                    <div class="cjp-goal-item">
                        <span>Structură (parter + etaj + acoperiș)</span>
                        <strong><?php echo esc_html(number_format_i18n((float) ($totals['structure_target'] ?? 80000), 0)); ?> EUR</strong>
                    </div>
                    <div class="cjp-goal-item">
                        <span>Lucrări interioare</span>
                        <strong><?php echo esc_html(number_format_i18n((float) ($totals['interior_target'] ?? 100000), 0)); ?> EUR</strong>
                    </div>
                    <div class="cjp-goal-item cjp-goal-total">
                        <span>Obiectiv total</span>
                        <strong><?php echo esc_html(number_format_i18n((float) ($totals['eur_goal'] ?? 200000), 0)); ?> EUR</strong>
                    </div>
                </div>

                <div class="cjp-main-progress-wrap">
                    <div class="cjp-main-progress-meta">
                        <span>Progres donații</span>
                        <strong id="cjp-eur-progress-text"><?php echo esc_html(number_format_i18n((float) ($totals['eur_raised'] ?? 0), 2)); ?> / <?php echo esc_html(number_format_i18n((float) ($totals['eur_goal'] ?? 200000), 0)); ?> EUR</strong>
                    </div>
                    <div class="cjp-progress">
                        <div id="cjp-eur-progress-bar" class="cjp-progress-bar" style="width: <?php echo esc_attr((string) ((float) ($totals['percent'] ?? 0))); ?>%;"></div>
                    </div>
                </div>
            </section>

            <section class="cjp-section">
                <h2>Donații unice</h2>
                <div class="cjp-cards-grid">
                    <?php foreach ($one_time_cards as $card) : ?>
                        <article class="cjp-card">
                            <h3><?php echo esc_html((string) ($card['title'] ?? 'Donație')); ?></h3>
                            <p><?php echo esc_html((string) ($card['description'] ?? '')); ?></p>
                            <div class="cjp-price"><?php echo esc_html(number_format_i18n((float) ($card['price'] ?? 0), 0)); ?> <?php echo esc_html((string) ($card['currency'] ?? 'lei')); ?></div>
                            <a class="cjp-btn" href="<?php echo esc_url((string) ($card['link'] ?? '#')); ?>" target="_blank" rel="noopener">Donează</a>
                        </article>
                    <?php endforeach; ?>
                </div>
            </section>

            <section class="cjp-section">
                <h2>Donații lunare</h2>
                <div class="cjp-cards-grid cjp-cards-grid-monthly">
                    <?php foreach ($monthly_cards as $card) : ?>
                        <article class="cjp-card">
                            <h3><?php echo esc_html((string) ($card['title'] ?? 'Donație lunară')); ?></h3>
                            <div class="cjp-price"><?php echo esc_html(number_format_i18n((float) ($card['price'] ?? 0), 0)); ?> <?php echo esc_html((string) ($card['currency'] ?? 'lei')); ?></div>
                            <a class="cjp-btn" href="<?php echo esc_url((string) ($card['link'] ?? '#')); ?>" target="_blank" rel="noopener">Susține lunar</a>
                        </article>
                    <?php endforeach; ?>
                </div>
            </section>

            <section class="cjp-section">
                <h2>Progres materiale</h2>
                <div class="cjp-materials-grid" id="cjp-materials-grid">
                    <?php foreach ($materials as $key => $material) : ?>
                        <article class="cjp-material-card" data-key="<?php echo esc_attr((string) $key); ?>">
                            <div class="cjp-material-header">
                                <h3><?php echo esc_html((string) ($material['label'] ?? $key)); ?></h3>
                                <strong>
                                    <span class="cjp-current"><?php echo esc_html(number_format_i18n((float) ($material['current'] ?? 0), 2)); ?></span>
                                    /
                                    <span class="cjp-target"><?php echo esc_html(number_format_i18n((float) ($material['target'] ?? 0), 2)); ?></span>
                                    <span class="cjp-unit"><?php echo esc_html((string) ($material['unit'] ?? '')); ?></span>
                                </strong>
                            </div>
                            <div class="cjp-progress">
                                <div class="cjp-progress-bar cjp-material-progress" style="width: <?php echo esc_attr((string) ((float) ($material['percent'] ?? 0))); ?>%;"></div>
                            </div>
                        </article>
                    <?php endforeach; ?>
                </div>
            </section>

            <section class="cjp-section">
                <h2>Donații recente</h2>
                <div class="cjp-recent-list" id="cjp-recent-list">
                    <?php if (empty($recent)) : ?>
                        <p class="cjp-empty">Încă nu există donații înregistrate.</p>
                    <?php else : ?>
                        <?php foreach ($recent as $donation) : ?>
                            <div class="cjp-recent-item">
                                <div>
                                    <strong><?php echo esc_html((string) ($donation['donor_name'] ?? 'Donator anonim')); ?></strong>
                                    <span><?php echo esc_html((string) ($donation['donation_type'] ?? 'general_donation')); ?></span>
                                </div>
                                <div>
                                    <strong><?php echo esc_html(number_format_i18n((float) ($donation['amount'] ?? 0), 2)); ?> <?php echo esc_html((string) ($donation['currency'] ?? 'RON')); ?></strong>
                                    <span><?php echo esc_html(date_i18n('d.m.Y H:i', strtotime((string) ($donation['created_at'] ?? 'now')))); ?></span>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </section>
        </div>
        <?php

        return (string) ob_get_clean();
    }
}
